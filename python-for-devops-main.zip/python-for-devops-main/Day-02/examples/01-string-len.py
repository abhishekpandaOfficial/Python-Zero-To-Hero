text = "Python is awesome"
length = len(text)
print("Length of the string:", length)
